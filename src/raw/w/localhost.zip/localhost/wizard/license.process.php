<?
if($_POST['accepted'])
  nextPage('select');
?>
