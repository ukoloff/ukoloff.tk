<h2>Чего изволите?</h2>

<label>
  <input type='radio' name='action' value='Trump'>
  Трамп
</label>
<br>
<label>
  <input type='radio' name='action' value='Clinton'>
  Клинтон
</label>
<br>
<label>
  <input type='radio' name='action' value='EdRo'>
  Единая Россия
</label>
<br>
