Ваш выбор: <?= $_SESSION['president'] ?>
